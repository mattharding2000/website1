<style>
a:hover {
  	color: 	#FF8C00;
}
i:focus {
  	color: 	#FF8C00;
}
</style>
<nav class="ts-sidebar">
	<ul class="ts-sidebar-menu">
		<li class="ts-label">Main</li>
		<li><a href="dashboard.php"><i class="fa fa-dashboard" style="color:white"></i>Dashboard</a></li>		
		<li><a href="manage-products.php"><i class="fa fa-car" style="color:white"></i> Products</a></li>
		<li><a href="reg-users.php"><i class="fa fa-users" style="color:white"></i> Reg Users</a></li>
	</ul>
</nav>