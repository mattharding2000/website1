<div class="brand clearfix">
	<div class="col-sm-3 col-md-2">
        <img src="../images/logo.jpg" alt="image" width="60px" height="60px"/></a>
		</div>
        <div class="col-sm-9 col-md-10" style="text-align: center;">
		<a href="dashboard.php" style="font-size: 20px; color:white; ">Admin Panel</a>  
		<ul class="ts-profile-nav">
			<li><a href="logout.php">Logout &nbsp;&nbsp;<i class="fa fa-sign-out" style="color:white; font-size:14px"></i></a></li>
		</ul>
	</div>
	</div>
</div>
