Contact Form 
=============
Instructions for change source code of sending Email
	Step 1
		Open index.php file
	Step 2
		Change line no:59 
		Add gmail address which you want to use as SMTP server(Gmail address which you want to use to send email)
	Step 3
		Make the following changes to the email address you entered above,
			1. Sign in to your gmail account
			2. Visit "Account" window
			3. Turn on "2-Step Verification"
			4. Add "App Password" (by clicking "App Password" - bellow to "2-Step Verification")
			5. Then set password and Copy it
			6. After that paste the password on line no:60
	step 4
		Change the Gmail address on line no:64
		Gmail address which you used as SMTP server. (Enter the same Gmail entered above) 
	step 5
		Change the Gmail address on line no:65
		Email address where you want to receive emails 



Admin login
Url : localhost/ModelWeb/admin/index.php

Email: admin@gmail.com
Password : admin

Please contact me if you have any problem. I can help you.




